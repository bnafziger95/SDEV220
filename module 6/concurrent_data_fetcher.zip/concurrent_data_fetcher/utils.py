import requests
from bs4 import BeautifulSoup

def fetch_title(url):
    try:
        response = requests.get(url, timeout=5)
        soup = BeautifulSoup(response.text, "html.parser")
        return soup.title.string if soup.title else "No Title"
    except:
        return "Error"
    
def heavy_computation(text):
    # example: Fibonacci based on length
    n = len(text) % 30

    def fib(n):
        if n <= 1:
            return n
        return fib(n-1) + fib(n-2)
    
    return fib(n)