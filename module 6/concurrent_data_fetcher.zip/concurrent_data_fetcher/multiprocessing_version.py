import time
from concurrent.futures import ProcessPoolExecutor
from urls import URLS
from utils import fetch_title, heavy_computation

def process(url):
    title = fetch_title(url)
    return heavy_computation(title)

if __name__ == "__main__":
    start = time.time()

    with ProcessPoolExecutor() as executor:
        results = list(executor.map(process, URLS))

    end = time.time()

    print("Multiprocessing Time:", end - start)