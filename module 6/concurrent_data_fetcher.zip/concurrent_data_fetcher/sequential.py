import time 
from urls import URLS
from utils import fetch_title, heavy_computation

start = time.time()

results = []
for url in URLS:
    title = fetch_title(url)
    result = heavy_computation(title)
    results.append(result)

end = time.time()

print("Sequential Time:", end - start)