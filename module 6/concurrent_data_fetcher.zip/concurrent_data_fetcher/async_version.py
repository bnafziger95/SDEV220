import time
import asyncio
import aiohttp
from bs4 import BeautifulSoup
from utils import heavy_computation
from urls import URLS


async def fetch_title(session, url):
    try:
        async with session.get(url, timeout=5) as response:
            text = await response.text()
            soup = BeautifulSoup(text, "html.parser")
            return soup.title.string if soup.title else "No Title"
    except:
        return "Error"


async def process(url, session):
    title = await fetch_title(session, url)   # ✅ VALID (inside async)
    return heavy_computation(title)


async def main():
    async with aiohttp.ClientSession() as session:
        tasks = [process(url, session) for url in URLS]
        results = await asyncio.gather(*tasks)   # ✅ VALID (inside async)
        return results


# 👇 THIS is critical
if __name__ == "__main__":
    start = time.time()
    results = asyncio.run(main())   # runs the async code
    end = time.time()

    print("Async Time:", end - start)