import time
from concurrent.futures import ThreadPoolExecutor
from urls import URLS
from utils import fetch_title, heavy_computation

start = time.time()

def process(url):
    title = fetch_title(url)
    return heavy_computation(title)

with ThreadPoolExecutor(max_workers=10) as executor:
    results = list(executor.map(process, URLS))

end = time.time()

print("Threading Time:", end - start)